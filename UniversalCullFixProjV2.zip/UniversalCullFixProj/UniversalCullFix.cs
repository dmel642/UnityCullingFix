﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Harmony;
using System.Reflection;
using MelonLoader;
using UnityEngine;
using Valve.VR;
//using Valve.VRRenderingPackage;

namespace $safeprojectname$

{

    public class $safeprojectname$ : MelonMod
    {
        static private bool isCantedFov = false;
        static private Matrix4x4 projectionMatrix;
        static public Camera m_Camera;
        public static Vector2 tanHalfFov { get; private set; }

        static HarmonyInstance harmony = HarmonyInstance.Create("com.universal");


        public override void OnUpdate()
        {
			
			if(m_Camera) {
            
				if (isCantedFov)
				{
					m_Camera.cullingMatrix = projectionMatrix * m_Camera.worldToCameraMatrix;
				}
			
			}


        }

        public override void OnLevelWasInitialized(int level)
        {

            MelonLogger.Log("Starting mod");

            m_Camera = Camera.main;

            Valve.VR.CVRSystem hmd = OpenVR.System;
            //Valve.VRRenderingPackage.CVRSystem hmd = OpenVR.System;

            HmdMatrix34_t eyeToHeadL = hmd.GetEyeToHeadTransform(EVREye.Eye_Left);

            if (eyeToHeadL.m0 < 1)  //m0 = 1 for parallel projections
            {
                isCantedFov = true;
                float l_left = 0.0f, l_right = 0.0f, l_top = 0.0f, l_bottom = 0.0f;
                hmd.GetProjectionRaw(EVREye.Eye_Left, ref l_left, ref l_right, ref l_top, ref l_bottom);

                float eyeYawAngle = Mathf.Acos(eyeToHeadL.m0);  //since there are no x or z rotations, this is y only. 10 deg on Pimax

                tanHalfFov = new Vector2(
               Mathf.Max(-l_left, l_right),
               Mathf.Max(-l_top, l_bottom));


                float eyeHalfFov = Mathf.Atan(tanHalfFov.x);
                float tanCorrectedEyeHalfFovH = Mathf.Tan(eyeYawAngle + eyeHalfFov);

                //increase horizontal fov by the eye rotation angles
                projectionMatrix.m00 = 1 / tanCorrectedEyeHalfFovH;  //m00 = 0.1737 for Pimax

                //because of canting, vertical fov increases towards the corners. calculate the new maximum fov otherwise culling happens too early at corners
                float eyeFovLeft = Mathf.Atan(-l_left);
                float tanCorrectedEyeHalfFovV = tanHalfFov.y * Mathf.Cos(eyeFovLeft) / Mathf.Cos(eyeFovLeft + eyeYawAngle);
                projectionMatrix.m11 = 1 / tanCorrectedEyeHalfFovV;   //m11 = 0.3969 for Pimax

                //set the near and far clip planes
                projectionMatrix.m22 = -(m_Camera.farClipPlane + m_Camera.nearClipPlane) / (m_Camera.farClipPlane - m_Camera.nearClipPlane);
                projectionMatrix.m23 = -2 * m_Camera.farClipPlane * m_Camera.nearClipPlane / (m_Camera.farClipPlane - m_Camera.nearClipPlane);
                projectionMatrix.m32 = -1;

                MelonLogger.Log("Mod successful");

            }
            else
                isCantedFov = false;


        }


    }
}
