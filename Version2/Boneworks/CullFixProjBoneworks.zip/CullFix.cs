﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Harmony;
using System.Reflection;
using MelonLoader;
using UnityEngine;
using Valve.VR;
using Valve.VR.InteractionSystem;

namespace $safeprojectname$

{

    public class CullFix : MelonMod
    {
        static private bool isCantedFov = false;
        static private Camera m_Camera;
        static private Matrix4x4 projectionMatrix;

        static HarmonyInstance harmony = HarmonyInstance.Create("com.boneworks");

        internal static void Hook(MethodInfo original, MethodInfo hook)
        {
            harmony.Patch(original, postfix: new HarmonyMethod(hook));
            
        }

        public override void OnApplicationStart() // Runs after Game Initialization.
        {
            MelonModLogger.Log("OnApplicationStart");

            Hook(typeof(ValveCamera).GetMethod("OnEnable", BindingFlags.Public | BindingFlags.Instance), typeof(CullFix).GetMethod("OnEnableHook", BindingFlags.NonPublic | BindingFlags.Static));
            Hook(typeof(ValveCamera).GetMethod("OnDisable", BindingFlags.Public | BindingFlags.Instance), typeof(CullFix).GetMethod("OnDisableHook", BindingFlags.NonPublic | BindingFlags.Static));
            Hook(typeof(ValveCamera).GetMethod("OnPreCull", BindingFlags.Public | BindingFlags.Instance), typeof(CullFix).GetMethod("OnPreCullHook", BindingFlags.NonPublic | BindingFlags.Static));
            
        }


        internal static void OnEnableHook(ValveCamera __instance)
        {
            
            m_Camera = __instance.GetComponent<Camera>();
            HmdMatrix34_t eyeToHeadL = SteamVR.instance.hmd.GetEyeToHeadTransform(EVREye.Eye_Left);
            if (eyeToHeadL.m0 < 1)  //m0 = 1 for parallel projections
            {
                isCantedFov = true;
                float l_left = 0.0f, l_right = 0.0f, l_top = 0.0f, l_bottom = 0.0f;
                SteamVR.instance.hmd.GetProjectionRaw(EVREye.Eye_Left, ref l_left, ref l_right, ref l_top, ref l_bottom);
                float eyeYawAngle = Mathf.Acos(eyeToHeadL.m0);  //since there are no x or z rotations, this is y only. 10 deg on Pimax
                float eyeHalfFov = Mathf.Atan(SteamVR.instance.tanHalfFov.x);
                float tanCorrectedEyeHalfFovH = Mathf.Tan(eyeYawAngle + eyeHalfFov);

                //increase horizontal fov by the eye rotation angles
                projectionMatrix.m00 = 1 / tanCorrectedEyeHalfFovH;  //m00 = 0.1737 for Pimax

                //because of canting, vertical fov increases towards the corners. calculate the new maximum fov otherwise culling happens too early at corners
                float eyeFovLeft = Mathf.Atan(-l_left);
                float tanCorrectedEyeHalfFovV = SteamVR.instance.tanHalfFov.y * Mathf.Cos(eyeFovLeft) / Mathf.Cos(eyeFovLeft + eyeYawAngle);
                projectionMatrix.m11 = 1 / tanCorrectedEyeHalfFovV;   //m11 = 0.3969 for Pimax

                //set the near and far clip planes
                projectionMatrix.m22 = -(m_Camera.farClipPlane + m_Camera.nearClipPlane) / (m_Camera.farClipPlane - m_Camera.nearClipPlane);
                projectionMatrix.m23 = -2 * m_Camera.farClipPlane * m_Camera.nearClipPlane / (m_Camera.farClipPlane - m_Camera.nearClipPlane);
                projectionMatrix.m32 = -1;
            }
            else
                isCantedFov = false;

        }

        internal static void OnDisableHook(ValveCamera __instance)
        {
            
            if (isCantedFov)
            {
                isCantedFov = false;
                m_Camera.ResetCullingMatrix();
            }


        }

        internal static void OnPreCullHook(ValveCamera __instance)
        {
            if (isCantedFov)
            {
                m_Camera.cullingMatrix = projectionMatrix * m_Camera.worldToCameraMatrix;
            }

        }


    }
}
